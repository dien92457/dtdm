// document.addEventListener('DOMContentLoaded', function() {
//     const list_btn = document.querySelectorAll('.add-to-cart-btn');
//     const notificationBox = document.getElementById('notification');
//     for(let i = 0; i<list_btn.length; i++) {
//         list_btn[i].addEventListener('click', function () {
//             notificationBox.style.display = 'block';
//             setTimeout(function () {
//                 notificationBox.style.display = 'none';
//             }, 3000);
//         });
//     }
// });

