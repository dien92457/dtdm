<?php
$server = 'localhost';
$user = 'root';
$pwd = '';
$database = 'clothing_store';